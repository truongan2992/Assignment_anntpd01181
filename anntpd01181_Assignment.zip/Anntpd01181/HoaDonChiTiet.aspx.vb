﻿
Partial Class HoaDonChiTiet
    Inherits System.Web.UI.Page

End Class
