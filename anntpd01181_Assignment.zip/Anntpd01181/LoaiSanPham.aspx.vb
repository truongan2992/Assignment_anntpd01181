﻿
Partial Class LoaiSanPham
    Inherits System.Web.UI.Page

End Class
