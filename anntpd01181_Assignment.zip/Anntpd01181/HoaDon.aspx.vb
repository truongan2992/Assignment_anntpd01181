﻿
Partial Class HoaDon
    Inherits System.Web.UI.Page

End Class
