﻿
Partial Class KhachHang
    Inherits System.Web.UI.Page

End Class
